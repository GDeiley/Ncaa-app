
import PicksList from "@/components/ui/PickList"

function Home() {
    return (
        <div >
            <PicksList />
        </div>
    );
}
export default Home