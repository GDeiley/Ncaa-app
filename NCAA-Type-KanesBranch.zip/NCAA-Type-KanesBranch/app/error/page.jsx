import ErrorScreen from "@/components/errorScreen";

export default function ErrorPage() {
  return <ErrorScreen />
}